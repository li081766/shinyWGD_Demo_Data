#!/bin/bash

#SBATCH -p all
#SBATCH -c 4
#SBATCH --mem 8G
#SBATCH -o run_Whale_Constant_rates.sh.so%j
#SBATCH -e run_Whale_Constant_rates.sh.se%j

module load julia
sh ../script_bin/prepare_Whale_command.v2.sh ../species_timetree.updated.nwk ../selected_tree_ALE_files ../wgdNodes.updated.txt whale.jl Constant_rates 200
julia whale.jl
